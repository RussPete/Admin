using System;
using System.Configuration;

namespace Utils
{
	/// <summary>
	/// Summary description for WebConfig.
	/// </summary>
	public class WebConfig
	{
		AppSettingsReader AppSettings = null;

		public WebConfig()
		{
			AppSettings = new AppSettingsReader();
		}

		public string Str(string Key)
		{
			string Value = string.Empty;
			try
			{
				Value = (string)AppSettings.GetValue(Key, typeof(string));
			}
			catch (InvalidOperationException)
			{
			}

			return Value;
		}

		public long Long(String Key)
		{
			return (long)AppSettings.GetValue(Key, typeof(long));
		}

		public bool Bool(String Key)
		{
			try
			{
				return (bool)AppSettings.GetValue(Key, typeof(bool));
			}
			catch (Exception Ex)
			{
				return false;
			}
		}
	}
}
