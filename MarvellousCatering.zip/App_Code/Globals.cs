using System;
using System.Diagnostics;
using Utils;

namespace Globals
{
	/// <summary>
	/// Summary description for Globals.
	/// </summary>
	public class g
	{
		public const String WebBaseName = "http://localhost/MarvellousCatering/";
		//static public DB db = new DB();
		static public String User = "";
        static public PageAccess.AccessLevels UserAccessLevel;

		public g()
		{
			Debug.WriteLine("Global g");
		}
		~g()
		{
			Debug.WriteLine("Global g~");
		}
	}
}
