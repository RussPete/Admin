﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utils;

public partial class UnpaidJobs : System.Web.UI.Page
{
    protected WebPage Pg;
    protected DB db;

    protected decimal Subtotal = 0;
    protected decimal OtherTotal = 0;
    protected decimal SalesTaxTotal = 0;
    protected decimal Total = 0;
    protected decimal Balance = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        db = new DB();

        Pg = new WebPage("Images");
        Pg.CheckLogin(Path.GetFileNameWithoutExtension(Page.AppRelativeVirtualPath));

        // Put user code to initialize the page here
        if (!Page.IsPostBack)
        {
            Session["Menu"] = WebPage.Accounting.Title;
            //Setup();
        }
        else
        {
            DateTime Tm = DateTime.Now;

            //// Recently edited finalized jobs
            //int Count = Str.Num(Request.Params["ReCount"]);
            //for (int i = 1; i <= Count; i++)
            //{
            //    int JobRno = Str.Num(Request.Params["chkReProc" + i]);
            //    if (JobRno > 0)
            //    {
            //        string Sql = "Select CCNum1, CCNum2, CCNum3 From mcJobs Where JobRno = " + JobRno;
            //        DataRow dr = db.DataRow(Sql);
            //        string CCNum1 = DecryptCCNum(dr, "1");
            //        string CCNum2 = DecryptCCNum(dr, "2");
            //        string CCNum3 = DecryptCCNum(dr, "3");
            //        if (CCNum1.Length > 0)
            //        {
            //            CCNum1 = "x" + Str.Right(CCNum1, 4);
            //        }
            //        if (CCNum2.Length > 0)
            //        {
            //            CCNum2 = "x" + Str.Right(CCNum2, 4);
            //        }
            //        if (CCNum3.Length > 0)
            //        {
            //            CCNum3 = "x" + Str.Right(CCNum3, 4);
            //        }

            //        Sql = "Update mcJobs Set " +
            //            "EditProcessedDtTm = Null, " +
            //            "EditProcessedUser = Null, " +
            //            "CCSecCode1 = Null, CCSecCode2 = Null, CCSecCode3 = Null, " +
            //            "CCNum1 = " + DB.PutStr(CCNum1) + ", " +
            //            "CCNum2 = " + DB.PutStr(CCNum2) + ", " +
            //            "CCNum3 = " + DB.PutStr(CCNum3) + ", " +
            //            "UpdatedDtTm = " + DB.PutDtTm(Tm) + ", " +
            //            "UpdatedUser = " + DB.PutStr(g.User) + " " +
            //            "Where JobRno = " + JobRno;
            //        db.Exec(Sql);
            //    }
            //}

            //// Finalized jobs
            //Count = Str.Num(Request.Params["Count"]);
            //for (int i = 1; i <= Count; i++)
            //{
            //    int JobRno = Str.Num(Request.Params["chkProc" + i]);
            //    if (JobRno > 0)
            //    {
            //        string Sql = "Select CCNum1, CCNum2, CCNum3 From mcJobs Where JobRno = " + JobRno;
            //        DataRow dr = db.DataRow(Sql);
            //        string CCNum1 = DecryptCCNum(dr, "1");
            //        string CCNum2 = DecryptCCNum(dr, "2");
            //        string CCNum3 = DecryptCCNum(dr, "3");
            //        if (CCNum1.Length > 0)
            //        {
            //            CCNum1 = "x" + Str.Right(CCNum1, 4);
            //        }
            //        if (CCNum2.Length > 0)
            //        {
            //            CCNum2 = "x" + Str.Right(CCNum2, 4);
            //        }
            //        if (CCNum3.Length > 0)
            //        {
            //            CCNum3 = "x" + Str.Right(CCNum3, 4);
            //        }

            //        Sql = "Update mcJobs Set " +
            //            "ProcessedDtTm = " + DB.PutDtTm(Tm) + ", " +
            //            "ProcessedUser = " + DB.PutStr(g.User) + ", " +
            //            "CCSecCode1 = Null, CCSecCode2 = Null, CCSecCode3 = Null, " +
            //            "CCNum1 = " + DB.PutStr(CCNum1) + ", " +
            //            "CCNum2 = " + DB.PutStr(CCNum2) + ", " +
            //            "CCNum3 = " + DB.PutStr(CCNum3) + ", " +
            //            "UpdatedDtTm = " + DB.PutDtTm(Tm) + ", " +
            //            "UpdatedUser = " + DB.PutStr(g.User) + " " +
            //            "Where JobRno = " + JobRno;
            //        db.Exec(Sql);
            //    }
            //}
        }
    }

    protected string Jobs()
    {
        string Html = string.Empty;
        string Sql = string.Empty;

        try
        {
            decimal RptTotal = 0;
            decimal RptTotalBalance = 0;

            int iRow = 0;

            string Where = "JobDate <= GetDate() and InvBalAmt > 0 and JobDate > '2017-1-1'";

            Sql = "Select * From mcJobs Where " + Where + " Order By JobDate, JobRno";
            DataTable dt = db.DataTable(Sql);
            foreach (DataRow dr in dt.Rows)
            {
                InvoiceAmounts(dr);

                string Customer         = DB.Str(dr["Customer"]);
                DateTime? Final         = DB.DtTm(dr["FinalDtTm"]);
                DateTime? Processed     = DB.DtTm(dr["ProcessedDtTm"]);
                DateTime? EditProcessed = DB.DtTm(dr["EditProcessedDtTm"]);
                DateTime? Updated       = DB.DtTm(dr["InvUpdatedDtTm"]);

                if (Updated.HasValue && Updated.Value == DateTime.MinValue)
                    Updated = null;

                bool fUpdated = false;
                string Title = string.Empty;

                Html += string.Format(
                    "<tr class=\"{12}\">\n" +
                    "<td class=\"Center\"><input type=\"checkbox\" name=\"chkProc{0}\" value=\"{2}\" /></td>\n" +
                    "<td class=\"Right\" title=\"{13}\">{11}<a href=\"Invoice.aspx?JobRno={2}\" target=\"invoice\">{2}</a></td>\n" +
                    "<td>{3}</td>\n" +
                    "<td class=\"Center\">{4}</td>\n" +
                    "<td>{5}</td>\n" +
                    "<td class=\"Right\">{6}</td>\n" +
                    "<td class=\"Right\">{7}</td>\n" +
                    "<td class=\"Right\">{8}</td>\n" +
                    "<td class=\"Right\">{9}</td>\n" +
                    "<td class=\"Right\">{10}</td>\n" +
                    "</tr>\n",
                    ++iRow,
                    "",
                    DB.Int32(dr["JobRno"]),
                    DB.Str(dr["Customer"]),
                    Fmt.Dt(DB.DtTm(dr["JobDate"])),
                    DB.Str(dr["Location"]),
                    Fmt.Dollar(Subtotal),
                    Fmt.Dollar(OtherTotal),
                    Fmt.Dollar(SalesTaxTotal),
                    Fmt.Dollar(Total),
                    Fmt.Dollar(Balance),
                    (fUpdated ? "*" : ""),
                    (fUpdated ? "Updated" : ""),
                    Title);
                RptTotal += Math.Round(Total, 2);
                RptTotalBalance += Math.Round(Balance, 2);

                Html += CCPayment(dr, "1");
                Html += CCPayment(dr, "2");
                Html += CCPayment(dr, "3");
            }

            Html += string.Format(
                "<tr>\n" +
                "<td><input type=\"hidden\" name=\"{0}Count\" value=\"{1}\"/></td>\n" +
                //"<td colspan=\"2\"><span style='color: Red;'>*</span><span style='font-size: 80%'>Updated</span></td>\n" +
                "<td colspan=\"2\"></td>\n" +
                "<td colspan=\"2\"></td>\n" +
                "<td align=\"right\"><b>Count</b></td>\n" +
                "<td align=\"right\"><b>{2}</b></td>\n" +
                "<td align=\"right\"><b>Total</b></td>\n" +
                "<td align=\"right\"><b>{3}</b></td>\n" +
                "<td align=\"right\"><b>{4}</b></td>\n" +
                "</tr>\n",
                "",
                iRow,
                dt.Rows.Count,
                Fmt.Dollar(RptTotal),
                Fmt.Dollar(RptTotalBalance));
        }
        catch (Exception Ex)
        {
            Err Err = new Err(Ex, Sql);
            Response.Write(Err.Html());
        }

        return Html;
    }

    protected string CCPayment(DataRow dr, string PmtNum)
    {
        string Html = string.Empty;

        try
        {
            string CCNum   = DB.Str(dr["CCNum" + PmtNum]);
            string SecCode = DB.Str(dr["CCSecCode" + PmtNum]);

            try
            {
                CCNum = Crypt.Decrypt(CCNum, Misc.Password);
            }
            catch (Exception)
            {
            }

            try
            {
                SecCode = Crypt.Decrypt(SecCode, Misc.Password);
            }
            catch (Exception)
            {
            }

            if (CCNum.Length > 0)
            {
                string CardInfo = string.Format(
                        "<dl>\n" +
                        "<dt>Amount</dt><dd class=\"mid\">{7}</dd>\n" +
                        "<dt>Card Type</dt><dd>{0}</dd>\n" +
                        "<dt>Exp Date</dt><dd class=\"short\">{2}</dd>\n" +
                        "<dt>Name</dt><dd class=\"long\">{4}</dd>\n" +
                        "<dt></dt><dd class=\"mid\"></dd>\n" +
                        "<dt>Card Num</dt><dd>{1}</dd>\n" +
                        "<dt>Sec Code</dt><dd class=\"short\">{3}</dd>\n" +
                        "<dt>Addr / Zip</dt><dd class=\"long\">{5} / {6}</dd>\n" +
                        "</dl>",
                        DB.Str(dr["CCType" + PmtNum]),
                        CCNum,
                        DB.Str(dr["CCExpDt" + PmtNum]),
                        SecCode,
                        DB.Str(dr["CCName" + PmtNum]),
                        DB.Str(dr["CCAddr" + PmtNum]),
                        DB.Str(dr["CCZip" + PmtNum]),
                        Fmt.Dollar(DB.Dec(dr["PmtAmt" + PmtNum])));
                Html += string.Format(
                    "<tr><td colspan=\"11\" class=\"nil\" /></tr>\n" +
                    "<tr>\n" +
                    "<td colspan=\"2\" />\n" +
                    "<td colspan=\"8\">{0}</td>\n" +
                    "</tr>\n",
                    CardInfo);
            }

        }
        catch (Exception Ex)
        {
            Err Err = new Err(Ex);
            Response.Write(Err.Html());
        }

        return Html;
    }

    protected void InvoiceAmounts(DataRow dr)
    {
        Subtotal        = DB.Dec(dr["SubTotAmt"]);
        OtherTotal      = DB.Dec(dr["PreTaxSubTotAmt"]) - Subtotal;
        SalesTaxTotal   = DB.Dec(dr["SalesTaxTotAmt"]);
        Total           = DB.Dec(dr["InvTotAmt"]);
        Balance         = DB.Dec(dr["InvBalAmt"]);
    }
}
