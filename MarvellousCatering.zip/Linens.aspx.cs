using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Utils;
using Globals;
using System.IO;

public partial class Linens : System.Web.UI.Page
{
	protected WebPage Pg;
	private DB db;
	protected String FocusField = "";
	protected Int32 JobRno;

    private void Page_Load(object sender, System.EventArgs e)
	{
		db = new DB();

		Pg = new WebPage("Images");
        Pg.CheckLogin(Path.GetFileNameWithoutExtension(Page.AppRelativeVirtualPath));
        JobRno = Pg.JobRno();

		// Put user code to initialize the page here
		if (!Page.IsPostBack)
		{
			Setup();
		}
	}

	private void Setup()
	{
		FocusField = "txtLinens";

		string Sql = string.Format("Select * From mcJobs Where JobRno = {0}", JobRno);

		try
		{
			DataTable dt = db.DataTable(Sql);
			if (dt != null)
			{
				DataRow dr = dt.Rows[0];

				txtMCC.Text = DB.Str(dr["MCCLinens"]);
				txtDiamond.Text = DB.Str(dr["DiamondLinens"]);
				txtSusan.Text = DB.Str(dr["SusanLinens"]);
				txtCUE.Text = DB.Str(dr["CUELinens"]);
				txtShirts.Text = DB.Str(dr["Shirts"]);
				txtAprons.Text = DB.Str(dr["Aprons"]);
			}
		}
		catch (Exception Ex)
		{
			Err Err = new Err(Ex);
			Response.Write(Err.Html());
		}
	}
	protected void btnShowUpdate_Click(object sender, EventArgs e)
	{
		string Sql = string.Format(
			"Update mcJobs Set " +
			"MCCLinens = {1}, " +
			"DiamondLinens = {2}, " +
			"SusanLinens = {3}, " +
			"CUELinens = {4}, " +
			"Shirts = {5}, " +
			"Aprons = {6} " +
			"Where JobRno = {0}",
			JobRno,
			DB.PutStr(txtMCC.Text, 200), 
			DB.PutStr(txtDiamond.Text, 200), 
			DB.PutStr(txtSusan.Text, 200), 
			DB.PutStr(txtCUE.Text, 200), 
			DB.PutStr(txtShirts.Text, 50), 
			DB.PutStr(txtAprons.Text, 50)
		);
		try
		{
			db.Exec(Sql);
		}
		catch (Exception Ex)
		{
			Err Err = new Err(Ex);
			Response.Write(Err.Html());
		}
	}
}