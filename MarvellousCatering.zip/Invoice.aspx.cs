using System;
using System.Data;
using System.IO;
using System.Net.Mail;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Utils;
using Globals;

public partial class Invoice : System.Web.UI.Page
{
	protected WebPage Pg;
	private DB db;
	protected String FocusField = "";
	protected Int32 JobRno;
	protected bool fNew = false;
	protected SelectList slAdj1Desc;
	protected SelectList slAdj2Desc;
	protected SelectList slInvMsg;
	protected SelectList slInvDeliveryMethod;
	protected SelectList slPaymentMsg;
	protected SelectList slInvPmtMethod;
	//protected SelectList slCCType;
	protected Utils.Calendar calInvDate;
	protected Utils.Calendar calInvDeliveryDate;
	protected Utils.Calendar calInvPmtDate;
	protected bool fPrinted = false;
	protected bool fJobCancelled = false;
	protected Int32 EventCount;
	protected string EventCountInfo;
	protected decimal PricePerPerson;
	protected bool fSaveFinal = false;
	protected int DefaultServings;
	protected const string CreditCard = "CreditCard";
	protected bool fChargeCCFee = false;
    protected string USAePayUrl;
    protected string USAePayKey;
    protected string User = g.User;

    private void Page_Init(object sender, System.EventArgs e)
	{
		WebConfig Conf = new WebConfig();
		fChargeCCFee = Conf.Bool("Charge CC Fee");
        USAePayUrl = Conf.Str("USAePay Gateway URL");
        USAePayKey = Conf.Str("USAePay Gateway Key");

        db = new DB();

		Pg = new WebPage("Images");
        Pg.CheckLogin(Path.GetFileNameWithoutExtension(Page.AppRelativeVirtualPath));

        Int32 ParmJobRno = Str.Num(Request.Params["JobRno"]);
		if (ParmJobRno != 0)
		{
			JobRno = ParmJobRno;
			Session["JobRno"] = JobRno.ToString();
		}

		if (JobRno == 0)
		{
			JobRno = Pg.JobRno();
		}

		SelectListsSetup();

		calInvDate = new Utils.Calendar("InvDate", ref txtInvDate);
		calInvDate.ImageButton(imgInvDate);

		//calInvDeliveryDate = new Utils.Calendar("InvDeliveryDate", ref txtInvDeliveryDate);
		//calInvDeliveryDate.ImageButton(imgInvDeliveryDate);

		//calInvPmtDate = new Utils.Calendar("InvPmtDate", ref txtInvPmtDate);
		//calInvPmtDate.ImageButton(imgInvPmtDate);

        if (!Page.IsPostBack)
        {
            hfPostCC1.Value =
            hfPostCC2.Value =
            hfPostCC3.Value = string.Empty;
        }
    }

	private void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
		if (!Page.IsPostBack)
		{
            if (Request.Params["UMstatus"] != null)
            {
                SaveCreditCardPayment();
            }

            Setup();
        }
        else
		{
			if (hfEmail.Value == "true")
			{
				SendEmail();
			}
		}

		SelectListsData();
	}

	private void Setup()
	{
		ReadValues();

		txtInvDate.Attributes.Add("onChange", "ValidateDateField('txtInvDate');CheckDate('txtInvDate');SetDirty();");
		//txtInvEventCount.Attributes.Add("onChange", "ValidateNum(this);CheckEventCount();SetDirty();");
		//txtInvPricePerPerson.Attributes.Add("onChange", "ValidateCurrency(this);CheckPricePerPerson();SetDirty();");
		txtSubTotTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtServiceSubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtServiceAmt');SetDirty();");
		txtServiceAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtServiceSubTotPct');SetDirty();");
		txtServiceTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtDeliverySubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtDeliveryAmt');SetDirty();");
		txtDeliveryAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtDeliverySubTotPct');SetDirty();");
		txtDeliveryTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtChinaSubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtChinaAmt');SetDirty();");
		txtChinaAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtChinaSubTotPct');SetDirty();");
		txtChinaTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtAddServiceSubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtAddServiceAmt');SetDirty();");
		txtAddServiceAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtAddServiceSubTotPct');SetDirty();");
		txtAddServiceTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtFuelTravelSubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtFuelTravelAmt');SetDirty();");
		txtFuelTravelAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtFuelTravelSubTotPct');SetDirty();");
		txtFuelTravelTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtFacilitySubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtFacilityAmt');SetDirty();");
		txtFacilityAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtFacilitySubTotPct');SetDirty();");
		txtFacilityTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtGratuitySubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtGratuityAmt');SetDirty();");
		txtGratuityAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtGratuitySubTotPct');SetDirty();");
		//txtGratuityTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtRentalsSubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtRentalsAmt');SetDirty();");
		txtRentalsAmt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtRentalsSubTotPct');SetDirty();");
		txtRentalsTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtAdj1SubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtAdj1Amt');SetDirty();");
		txtAdj1Desc.Attributes.Add("onChange", "SetDirty();");
		txtAdj1Amt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtAdj1SubTotPct');SetDirty();");
		txtAdj1TaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtAdj2SubTotPct.Attributes.Add("onChange", "ValidatePct(this, 3);ChangePct(this, 'txtAdj2Amt');SetDirty();");
		txtAdj2Desc.Attributes.Add("onChange", "SetDirty();");
		txtAdj2Amt.Attributes.Add("onChange", "ValidateCurrency(this);ChangeAmt(this, 'txtAdj2SubTotPct');SetDirty();");
		txtAdj2TaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtCCFeePct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		txtCCFeeTaxPct.Attributes.Add("onChange", "ValidatePct(this, 3);InvoiceTotal();SetDirty();");
		//txtDepositDate.Attributes.Add("style", "text-align: left;");
		//txtDepositAmt.Attributes.Add("onChange", "ValidateCurrency(this);InvoiceTotal();SetDirty();");
		//txtDepositRef.Attributes.Add("style", "text-align: left;");
		//txtInvMessage.Attributes.Add("onChange", "SetDirty();");
		//txtInvDeliveryMethod.Attributes.Add("onChange", "CheckDeliveryMethod();SetDirty();");
		//txtInvDeliveryDate.Attributes.Add("onChange", "ValidateDateField('txtInvDeliveryDate');CheckDate('txtInvDeliveryDate');SetDirty();");
		//txtInvEmail.Attributes.Add("onBlur", "CheckEmailDeliveryMethod();SetDirty();");
		//txtInvFax.Attributes.Add("onBlur", "CheckFaxDeliveryMethod();SetDirty();");
		//txtPaymentMsg.Attributes.Add("onChange", "SetDirty();");
		//txtInvPmtDate.Attributes.Add("onChange", "CheckDate('txtInvPmtDate');SetDirty();");
		//txtInvPmtMethod.Attributes.Add("onChange", "SetDirty();");
		//txtCheckRef.Attributes.Add("onChange", "SetDirty();");
		//txtCCType.Attributes.Add("onChange", "SetDirty();");
		//txtCCNum.Attributes.Add("onChange", "SetDirty();");
		//txtCCExpDt.Attributes.Add("onChange", "CheckCCExpDate();SetDirty();");
		//txtCCSecCode.Attributes.Add("onChange", "SetDirty();");
		//txtCCName.Attributes.Add("onChange", "SetDirty();");
		//txtCCStreet.Attributes.Add("onChange", "SetDirty();");
		//txtCCZip.Attributes.Add("onChange", "SetDirty();");
		//txtCCBatchID.Attributes.Add("onChange", "SetDirty();");
		//txtCCInvNum.Attributes.Add("onChange", "SetDirty();");
		//txtCCApprCode.Attributes.Add("onChange", "CheckCCFailed();SetDirty();");
		//txtCCAVSResp.Attributes.Add("onChange", "SetDirty();");
		//txtCCSettleDate.Attributes.Add("onChange", "CheckDate('txtCCSettleDate');SetDirty();");
		//chkFailedFlg.Attributes.Add("onClick", "CheckCCFailed();SetDirty();");
		//txtFailedMsg.Attributes.Add("onChange", "SetDirty();");

		btnSave.Attributes.Add("onClick", "ClearDirty();");
		//btnSave1.Attributes.Add("onClick", "ClearDirty();");
		chkCustomerCopy.Attributes.Add("OnClick", "SyncCustomerCopy(this);");
		//chkCustomerCopy1.Attributes.Add("OnClick", "SyncCustomerCopy(this);");
		chkFileCopy.Attributes.Add("OnClick", "SyncFileCopy(this);");
		//chkFileCopy1.Attributes.Add("OnClick", "SyncFileCopy(this);");

		chkCustomerCopy.Checked = true;
		//chkCustomerCopy1.Checked = true;
		chkFileCopy.Checked = false;
		//chkFileCopy1.Checked = false;
	}

	private void SelectListsSetup()
	{
		SelectList.Clear();

		slAdj1Desc = new SelectList("Adj1Desc", ref txtAdj1Desc);
		slAdj1Desc.ImageButton(ddAdj1Desc);

		slAdj2Desc = new SelectList("Adj2Desc", ref txtAdj2Desc);
		slAdj2Desc.ImageButton(ddAdj2Desc);

		//slInvMsg = new SelectList("InvMessage", ref txtInvMessage);
		//slInvMsg.ImageButton(ddInvMessage);

		//slInvDeliveryMethod = new SelectList("InvDeliveryMethod", ref txtInvDeliveryMethod);
		//slInvDeliveryMethod.ImageButton(ddInvDeliveryMethod);

		//slPaymentMsg = new SelectList("PaymentMsg", ref txtPaymentMsg);
		//slPaymentMsg.ImageButton(ddPaymentMsg);

		//slInvPmtMethod = new SelectList("InvPmtMethod", ref txtInvPmtMethod);
		//slInvPmtMethod.ImageButton(ddInvPmtMethod);

		//slCCType = new SelectList("CCType", ref txtCCType);
		//slCCType.ImageButton(ddCCType);
	}

	private void SelectListsData()
	{
		String Sql;

		Sql =
			"Select Distinct Adj1Desc From mcJobs " +
			"Union " +
			"Select Distinct Adj2Desc As Adj1Desc From mcJobs " +
			"Order By Adj1Desc";

		slAdj1Desc.ClearValues();
		slAdj1Desc.AddDBValues(db, Sql);

		slAdj2Desc.ClearValues();
		slAdj2Desc.AddDBValues(db, Sql);

		//Sql =
		//    "Select Distinct InvoiceMsg From mcJobs Order By InvoiceMsg";
		//slInvMsg.ClearValues();
		//slInvMsg.AddValue("Thank you for your business.");
		//slInvMsg.AddValue("Thank you for your prompt payment.");
		//slInvMsg.AddValue("We look forward to serving you again in the near future.");
		//slInvMsg.AddDBValues(db, Sql);

		//Sql =
		//    "Select Distinct InvDeliveryMethod From mcJobs Order By InvDeliveryMethod";
		//slInvDeliveryMethod.ClearValues();
		//slInvDeliveryMethod.AddValue("Customer Pick-up");
		//slInvDeliveryMethod.AddValue("Deliver with Job");
		//slInvDeliveryMethod.AddValue("Email");
		//slInvDeliveryMethod.AddValue("Fax");
		//slInvDeliveryMethod.AddValue("US Mail");
		//slInvDeliveryMethod.AddDBValues(db, Sql);

		//Sql =
		//    "Select Distinct PaymentMsg From mcJobs Order By PaymentMsg";
		//slPaymentMsg.ClearValues();
		//slPaymentMsg.AddValue("You will see the name PeteSoft, LLC on your credit card statement for these charges.");
		//slPaymentMsg.AddValue("You will see the name Rust Coin & Gift on your credit card statement for these charges.");
		//slPaymentMsg.AddDBValues(db, Sql);

		//Sql =
		//	"Select Distinct InvPmtMethod From mcJobs Order By InvPmtMethod";
		//slInvPmtMethod.ClearValues();
		//slInvPmtMethod.AddValue("Check");
		//slInvPmtMethod.AddValue("Cash");
		//slInvPmtMethod.AddValue("CC");
		//slInvPmtMethod.AddDBValues(db, Sql);

		//Sql =
		//	"Select Distinct CCType From mcJobs Order By CCType";
		//slCCType.ClearValues();
		//slCCType.AddDBValues(db, Sql);
	}

	private void ClearValues()
	{
		lblJobRno.Text =
		lblCustomer.Text =
		lblContactName.Text =
		txtInvDate.Text =
		txtJobDate.Text =
		//txtInvEventCount.Text =
		//txtInvPricePerPerson.Text =
		txtInvSubTotal.Text =
		txtSubTotTaxPct.Text =
		txtServiceSubTotPctFlg.Value =
		txtServiceSubTotPct.Text =
		txtServiceAmt.Text =
		txtServiceTaxPct.Text =
		txtDeliverySubTotPctFlg.Value =
		txtDeliverySubTotPct.Text =
		txtDeliveryAmt.Text =
		txtDeliveryTaxPct.Text =
		txtChinaSubTotPctFlg.Value =
		txtChinaSubTotPct.Text =
		txtChinaAmt.Text =
		txtChinaTaxPct.Text =
		txtAddServiceSubTotPctFlg.Value =
		txtAddServiceSubTotPct.Text =
		txtAddServiceAmt.Text =
		txtAddServiceTaxPct.Text =
		txtFuelTravelSubTotPctFlg.Value =
		txtFuelTravelSubTotPct.Text =
		txtFuelTravelAmt.Text =
		txtFuelTravelTaxPct.Text =
		txtFacilitySubTotPctFlg.Value =
		txtFacilitySubTotPct.Text =
		txtFacilityAmt.Text =
		txtFacilityTaxPct.Text =
		txtGratuitySubTotPctFlg.Value =
		txtGratuitySubTotPct.Text =
		txtGratuityAmt.Text =
		//txtGratuityTaxPct.Text =
		txtRentalsSubTotPctFlg.Value =
		txtRentalsSubTotPct.Text =
		txtRentalsAmt.Text =
		txtRentalsTaxPct.Text =
		txtRentalsDesc.Text =
		txtAdj1SubTotPctFlg.Value =
		txtAdj1SubTotPct.Text =
		txtAdj1Desc.Text =
		txtAdj1Amt.Text =
		txtAdj1TaxPct.Text =
		txtAdj2SubTotPctFlg.Value =
		txtAdj2SubTotPct.Text =
		txtAdj2Desc.Text =
		txtAdj2Amt.Text =
		txtAdj2TaxPct.Text =
		txtCCFeePct.Text =
		txtCCFeeAmt.Text =
		txtCCFeeTaxPct.Text =
		txtPreTaxTotal.Text =
		txtSalesTaxTotal.Text =
		txtInvTotal.Text =
		//txtDepositDate.Text =
		//txtDepositAmt.Text =
		//txtDepositRef.Text =
 		lblPmtType1.Text =
		txtPmtAmtDisp1.Text =
		lblPmtRef1.Text =
		txtPmtAmt1.Value =
		txtPmtType1.Value =
		txtPmtRef1.Value =
		txtPmtDt1.Value = 
		txtPmtMethod1.Value = 
        txtCCStatus1.Value = 
        txtCCAuth1.Value =
        txtCCResult1.Value =
        //txtCCReqAmt1.Value = 
        //txtCCType1.Value = 
        //txtCCNum1.Value = 
        //txtCCExpDt1.Value = 
        //txtCCSecCode1.Value =
        //txtCCName1.Value = 
        //txtCCAddr1.Value = 
        //txtCCZip1.Value =
        lblPmtType2.Text =
		txtPmtAmtDisp2.Text =
		lblPmtRef2.Text =
		txtPmtAmt2.Value =
		txtPmtType2.Value =
		txtPmtRef2.Value =
		txtPmtDt2.Value =
		txtPmtMethod2.Value =
        txtCCStatus2.Value =
        txtCCAuth2.Value =
        txtCCResult2.Value =
        //txtCCReqAmt2.Value =
        //txtCCType2.Value =
        //txtCCNum2.Value =
        //txtCCExpDt2.Value =
        //txtCCSecCode2.Value =
        //txtCCName2.Value =
        //txtCCAddr2.Value =
        //txtCCZip2.Value =
        lblPmtType3.Text =
		txtPmtAmtDisp3.Text =
		lblPmtRef3.Text =
		txtPmtAmt3.Value =
		txtPmtType3.Value =
		txtPmtRef3.Value =
		txtPmtDt3.Value =
		txtPmtMethod3.Value =
        txtCCStatus3.Value =
        txtCCAuth3.Value =
        txtCCResult3.Value =
        //txtCCReqAmt3.Value =
        //txtCCType3.Value =
        //txtCCNum3.Value =
        //txtCCExpDt3.Value =
        //txtCCSecCode3.Value =
        //txtCCName3.Value =
        //txtCCAddr3.Value =
        //txtCCZip3.Value =
        txtInvBalance.Text = 
        txtDepositAmt.Text =
        hfDepositAmt.Value =
        hfDepositInvoice.Value =
		//txtInvMessage.Text =
		//txtInvDeliveryMethod.Text =
		//txtInvDeliveryDate.Text =
		//txtInvEmail.Text =
		//txtInvFax.Text =
		//txtPaymentMsg.Text =
		//txtInvPmtDate.Text =
		//txtInvPmtMethod.Text =
		//txtCheckRef.Text =
		//txtCCType.Text =
		//txtCCNum.Text =
		//txtCCExpDt.Text =
		//txtCCSecCode.Text =
		//txtCCName.Text =
		//txtCCStreet.Text =
		//txtCCZip.Text =
		//txtCCBatchID.Text =
		//txtCCInvNum.Text =
		//txtCCApprCode.Text =
		//txtCCAVSResp.Text =
		//txtCCSettleDate.Text = 
		//txtFailedMsg.Text =
		lblSaveDt.Text =
		lblSaveFinalDt.Text =
		lblPrintDt.Text =
		lblEmailDt.Text = 
		txtInvCreatedDt.Text =
		txtInvCreatedUser.Text =
		txtInvUpdatedDt.Text =
		txtInvUpdatedUser.Text =
        txtDepositInvPrintedDtTm.Text =
        txtDepositInvPrintedUser.Text =
        txtDepositInvEmailedDtTm.Text =
        txtDepositInvEmailedUser.Text =
        txtEmail.Text =
		txtSubject.Text =
		txtMessage.Text = string.Empty;
		//chkFailedFlg.Checked = false;

		//			chkCustomerCopy.Checked		=
		//			chkCustomerCopy1.Checked	= true;
		//			chkFileCopy.Checked			=
		//			chkFileCopy1.Checked		= false;

		EventCount = 0;
		EventCountInfo = "";
		PricePerPerson = 0M;
	}

	private void ReadValues()
	{
		ClearValues();

		String Sql = "Select * From mcJobs Where JobRno = " + JobRno;
		DataTable tbl = db.DataTable(Sql);
		if (tbl.Rows.Count > 0)
		{
			DataRow dr = tbl.Rows[0];

			string InvCreatedDt = Fmt.DtTm(DB.DtTm(dr["InvCreatedDtTm"]));
			bool fNew = (InvCreatedDt.Length == 0);

			string CancelledDt = Fmt.DtTm(DB.DtTm(dr["CancelledDtTm"]));
			fJobCancelled = (CancelledDt.Length > 0);

			int InvEventCount = DB.Int32(dr["InvEventCount"]);
			int cMen = DB.Int32(dr["NumMenServing"]);
			int cWomen = DB.Int32(dr["NumWomenServing"]);
			int cChild = DB.Int32(dr["NumChildServing"]);
			EventCount = cMen + cWomen + cChild;
			decimal InvPricePerPerson = DB.Dec(dr["InvPricePerPerson"]);
			PricePerPerson = DB.Dec(dr["PricePerPerson"]);
			DateTime InvDate = DB.DtTm(dr["InvDate"]);

			EventCountInfo =
				"Job Count is " + Fmt.Num(cMen + cWomen + cChild) + " (" +
				Fmt.Num(cMen) + " Men, " +
				Fmt.Num(cWomen) + " Women, " +
				Fmt.Num(cChild) + " Child)";

			decimal ServiceAmt      = DB.Dec(dr["ServiceAmt"]);
			decimal DeliveryAmt     = DB.Dec(dr["DeliveryAmt"]);
			decimal ChinaAmt        = DB.Dec(dr["ChinaAmt"]);
			decimal AddServiceAmt   = DB.Dec(dr["AddServiceAmt"]);
			decimal FuelTravelAmt   = DB.Dec(dr["FuelTravelAmt"]);
			decimal FacilityAmt     = DB.Dec(dr["FacilityAmt"]);
			decimal GratuityAmt     = DB.Dec(dr["GratuityAmt"]);
			decimal RentalsAmt      = DB.Dec(dr["RentalsAmt"]);
			decimal Adj1Amt         = DB.Dec(dr["Adj1Amt"]);
			decimal Adj2Amt         = DB.Dec(dr["Adj2Amt"]);

			decimal SubTotTaxPct        = DB.Dec(dr["SubTotTaxPct"]);
			decimal ServiceTaxPct       = DB.Dec(dr["ServiceTaxPct"]);
			decimal DeliveryTaxPct      = DB.Dec(dr["DeliveryTaxPct"]);
			decimal ChinaTaxPct         = DB.Dec(dr["ChinaTaxPct"]);
			decimal AddServiceTaxPct    = DB.Dec(dr["AddServiceTaxPct"]);
			decimal FuelTravelTaxPct    = DB.Dec(dr["FuelTravelTaxPct"]);
			decimal FacilityTaxPct      = DB.Dec(dr["FacilityTaxPct"]);
			//decimal GratuityTaxPct    = DB.Dec(dr["GratuityTaxPct"]);
			decimal RentalsTaxPct       = DB.Dec(dr["RentalsTaxPct"]);
			decimal Adj1TaxPct          = DB.Dec(dr["Adj1TaxPct"]);
			decimal Adj2TaxPct          = DB.Dec(dr["Adj2TaxPct"]);
			decimal CCFeeTaxPct         = DB.Dec(dr["CCFeeTaxPct"]);

			decimal ServiceSubTotPct    = DB.Dec(dr["ServiceSubTotPct"]);
			decimal DeliverySubTotPct   = DB.Dec(dr["DeliverySubTotPct"]);
			decimal ChinaSubTotPct      = DB.Dec(dr["ChinaSubTotPct"]);
			decimal AddServiceSubTotPct = DB.Dec(dr["AddServiceSubTotPct"]);
			decimal FuelTravelSubTotPct = DB.Dec(dr["FuelTravelSubTotPct"]);
			decimal FacilitySubTotPct   = DB.Dec(dr["FacilitySubTotPct"]);
			decimal GratuitySubTotPct   = DB.Dec(dr["GratuitySubTotPct"]);
			decimal RentalsSubTotPct    = DB.Dec(dr["RentalsSubTotPct"]);
			decimal CCFeePct            = DB.Dec(dr["CCFeePct"]);

			bool ServiceSubTotPctFlg    = DB.Bool(dr["ServiceSubTotPctFlg"]);
			bool DeliverySubTotPctFlg   = DB.Bool(dr["DeliverySubTotPctFlg"]);
			bool ChinaSubTotPctFlg      = DB.Bool(dr["ChinaSubTotPctFlg"]);
			bool AddServiceSubTotPctFlg = DB.Bool(dr["AddServiceSubTotPctFlg"]);
			bool FuelTravelSubTotPctFlg = DB.Bool(dr["FuelTravelSubTotPctFlg"]);
			bool FacilitySubTotPctFlg   = DB.Bool(dr["FacilitySubTotPctFlg"]);
			bool GratuitySubTotPctFlg   = DB.Bool(dr["GratuitySubTotPctFlg"]);
			bool RentalsSubTotPctFlg    = DB.Bool(dr["RentalsSubTotPctFlg"]);

			decimal DepositAmt  = DB.Dec(dr["DepositAmt"]);

            string PmtType1     = DB.Str(dr["PmtType1"]);
			decimal PmtAmt1     = DB.Dec(dr["PmtAmt1"]);
			DateTime PmtDt1     = DB.DtTm(dr["PmtDt1"]);
			string PmtRef1      = DB.Str(dr["PmtRef1"]);
			string PmtMethod1   = DB.Str(dr["PmtMethod1"]);
            string CCStatus1    = DB.Str(dr["CCStatus1"]);
            string CCAuth1      = DB.Str(dr["CCAuth1"]);
            string CCResult1    = DB.Str(dr["CCResult1"]);
            //decimal CCReqAmt1 = DB.Dec(dr["CCReqAmt1"]);
            //string CCType1    = DB.Str(dr["CCType1"]);
            //string CCNum1     = DB.Str(dr["CCNum1"]);
            //string CCExpDt1   = DB.Str(dr["CCExpDt1"]);
            //string CCSecCode1 = DB.Str(dr["CCSecCode1"]);
            //string CCName1    = DB.Str(dr["CCName1"]);
            //string CCAddr1    = DB.Str(dr["CCAddr1"]);
            //string CCZip1     = DB.Str(dr["CCZip1"]);

			string PmtType2     = DB.Str(dr["PmtType2"]);
            decimal PmtAmt2     = DB.Dec(dr["PmtAmt2"]);
			DateTime PmtDt2     = DB.DtTm(dr["PmtDt2"]);
			string PmtRef2      = DB.Str(dr["PmtRef2"]);
			string PmtMethod2   = DB.Str(dr["PmtMethod2"]);
            string CCStatus2    = DB.Str(dr["CCStatus2"]);
            string CCAuth2      = DB.Str(dr["CCAuth2"]);
            string CCResult2    = DB.Str(dr["CCResult2"]);
			//decimal CCReqAmt2   = DB.Dec(dr["CCReqAmt2"]);
			//string CCType2      = DB.Str(dr["CCType2"]);
			//string CCNum2       = DB.Str(dr["CCNum2"]);
			//string CCExpDt2     = DB.Str(dr["CCExpDt2"]);
			//string CCSecCode2   = DB.Str(dr["CCSecCode2"]);
			//string CCName2      = DB.Str(dr["CCName2"]);
			//string CCAddr2      = DB.Str(dr["CCAddr2"]);
			//string CCZip2       = DB.Str(dr["CCZip2"]);

			string PmtType3     = DB.Str(dr["PmtType3"]);
			decimal PmtAmt3     = DB.Dec(dr["PmtAmt3"]);
			DateTime PmtDt3     = DB.DtTm(dr["PmtDt3"]);
			string PmtRef3      = DB.Str(dr["PmtRef3"]);
			string PmtMethod3   = DB.Str(dr["PmtMethod3"]);
            string CCStatus3    = DB.Str(dr["CCStatus3"]);
            string CCAuth3      = DB.Str(dr["CCAuth3"]);
            string CCResult3    = DB.Str(dr["CCResult3"]);
			//decimal CCReqAmt3   = DB.Dec(dr["CCReqAmt3"]);
			//string CCType3      = DB.Str(dr["CCType3"]);
			//string CCNum3       = DB.Str(dr["CCNum3"]);
			//string CCExpDt3     = DB.Str(dr["CCExpDt3"]);
			//string CCSecCode3   = DB.Str(dr["CCSecCode3"]);
			//string CCName3      = DB.Str(dr["CCName3"]);
			//string CCAddr3      = DB.Str(dr["CCAddr3"]);
			//string CCZip3       = DB.Str(dr["CCZip3"]);

			string InvEmail         = DB.Str(dr["InvEmail"]);
			string InvFax           = DB.Str(dr["InvFax"]);
			//string InvPmtMethod   = DB.Str(dr["InvPmtMethod"]);
			DateTime dtInvEmailed   = DB.DtTm(dr["InvEmailedDtTm"]);

			if (fNew)
			{
				Sql = "Select * From Settings Where SettingRno = 1";
				try
				{
					InvDate             = DateTime.Today;
					InvEventCount       = EventCount;
					InvPricePerPerson   = PricePerPerson;
					InvEmail            = DB.Str(dr["ContactEmail"]);
					InvFax              = DB.Str(dr["ContactFax"]);
					//InvPmtMethod      = DB.Str(dr["PmtMethod"]);

					DataRow drSettings = db.DataRow(Sql);
					if (drSettings != null)
					{
						SubTotTaxPct        = DB.Dec(drSettings["SubTotTaxPct"]);
						//GratuityTaxPct    = DB.Dec(drSettings["GratuityTaxPct"]);
						ServiceTaxPct       = DB.Dec(drSettings["ServiceTaxPct"]);
						DeliveryTaxPct      = DB.Dec(drSettings["DeliveryTaxPct"]);
						ChinaTaxPct         = DB.Dec(drSettings["ChinaTaxPct"]);
						AddServiceTaxPct    = DB.Dec(drSettings["AddServiceTaxPct"]);
						FuelTravelTaxPct    = DB.Dec(drSettings["FuelTravelTaxPct"]);
						FacilityTaxPct      = DB.Dec(drSettings["FacilityTaxPct"]);
						RentalsTaxPct       = DB.Dec(drSettings["RentalsTaxPct"]);
						Adj1TaxPct          = DB.Dec(drSettings["Adj1TaxPct"]);
						Adj2TaxPct          = DB.Dec(drSettings["Adj2TaxPct"]);
						CCFeePct            = DB.Dec(drSettings["CCFeePct"]);

						GratuitySubTotPct   = DB.Dec(drSettings["GratuitySubTotPct"]);
						ServiceSubTotPct    = DB.Dec(drSettings["ServiceSubTotPct"]);
						DeliverySubTotPct   = DB.Dec(drSettings["DeliverySubTotPct"]);
						ChinaSubTotPct      = DB.Dec(drSettings["ChinaSubTotPct"]);
						AddServiceSubTotPct = DB.Dec(drSettings["AddServiceSubTotPct"]);
						FuelTravelSubTotPct = DB.Dec(drSettings["FuelTravelSubTotPct"]);
						FacilitySubTotPct   = DB.Dec(drSettings["FacilitySubTotPct"]);
						RentalsSubTotPct    = DB.Dec(drSettings["RentalsSubTotPct"]);
						CCFeeTaxPct         = DB.Dec(drSettings["CCFeeTaxPct"]);

						GratuitySubTotPctFlg    = (GratuitySubTotPct != 0);
						ServiceSubTotPctFlg     = (ServiceSubTotPct != 0);
						DeliverySubTotPctFlg    = (DeliverySubTotPct != 0);
						ChinaSubTotPctFlg       = (ChinaSubTotPct != 0);
						AddServiceSubTotPctFlg  = (AddServiceSubTotPct != 0);
						FuelTravelSubTotPctFlg  = (FuelTravelSubTotPct != 0);
						FacilitySubTotPctFlg    = (FacilitySubTotPct != 0);
						RentalsSubTotPctFlg     = (RentalsSubTotPct != 0);
					}
				}
				catch (Exception Ex)
				{
					Err Err = new Err(Ex, Sql);
					Response.Write(Err.Html());
				}
			}

			//decimal InvSubTotal = InvEventCount * InvPricePerPerson + AdditionalPrices(InvEventCount, InvPricePerPerson, SubTotTaxPct);
			AdditionalPrices(InvEventCount, InvPricePerPerson, SubTotTaxPct);
			//AdditionalPrices(InvEventCount, InvPricePerPerson, SubTotTaxPct);
			decimal InvSubTotal = DB.Dec(dr["SubTotAmt"]);

			//CCNum1 = Decrypt(CCNum1);
			//CCNum2 = Decrypt(CCNum2);
			//CCNum3 = Decrypt(CCNum3);

			//CCSecCode1 = Decrypt(CCSecCode1);
			//CCSecCode2 = Decrypt(CCSecCode2);
			//CCSecCode3 = Decrypt(CCSecCode3);

			lblJobRno.Text      = DB.Str(JobRno);
			lblCustomer.Text    = DB.Str(dr["Customer"]);
			lblContactName.Text = DB.Str(dr["ContactName"]);
			txtInvDate.Text     = Fmt.Dt(InvDate);
			txtJobDate.Text     = Fmt.Dt(DB.DtTm(dr["JobDate"]));
			//txtInvEventCount.Text     = Fmt.Num(InvEventCount);
			//txtInvPricePerPerson.Text = Fmt.Dollar(InvPricePerPerson, false);
			//txtInvExtPrice.Text       = Fmt.Dollar(InvEventCount * InvPricePerPerson, false);
			txtInvSubTotal.Text         = Fmt.Dollar(InvSubTotal, false);
			chkSalesTaxExempt.Checked   = DB.Bool(dr["TaxExemptFlg"]);
			txtSubTotTaxPct.Text        = Fmt.Pct(SubTotTaxPct, 3, false);
			txtServiceTaxPct.Text       = Fmt.Pct(ServiceTaxPct, 3, false);
			txtDeliveryTaxPct.Text      = Fmt.Pct(DeliveryTaxPct, 3, false);
			txtChinaTaxPct.Text         = Fmt.Pct(ChinaTaxPct, 3, false);
			txtAddServiceTaxPct.Text    = Fmt.Pct(AddServiceTaxPct, 3, false);
			txtFuelTravelTaxPct.Text    = Fmt.Pct(FuelTravelTaxPct, 3, false);
			txtFacilityTaxPct.Text      = Fmt.Pct(FacilityTaxPct, 3, false);
			//txtGratuityTaxPct.Text    = Fmt.Pct(GratuityTaxPct, 3, false);
			txtRentalsTaxPct.Text       = Fmt.Pct(RentalsTaxPct, 3, false);
			txtRentalsDesc.Text         = DB.Str(dr["RentalsDesc"]);
			txtAdj1Desc.Text            = DB.Str(dr["Adj1Desc"]);
			txtAdj1TaxPct.Text          = Fmt.Pct(Adj1TaxPct, 3, false);
			txtAdj2Desc.Text            = DB.Str(dr["Adj2Desc"]);
			txtAdj2TaxPct.Text          = Fmt.Pct(Adj2TaxPct, 3, false);
			chkCCPmtFee.Checked         = (DB.Bool(dr["CCPmtFeeFlg"]) || dr["CCPmtFeeFlg"] == DBNull.Value && DB.Str(dr["PmtMethod"]) == "CC");
			txtCCFeePct.Text            = Fmt.Pct(CCFeePct, 3, false);
			txtCCFeeTaxPct.Text         = Fmt.Pct(CCFeeTaxPct, 3, false);

            //txtDepositDate.Text       = Fmt.Dt(DB.DtTm(dr["DepDtTm"]));
            //txtDepositAmt.Text        = Fmt.Dollar(DepositAmt);
            //txtDepositRef.Text        = DB.Str(dr["DepRef"]);
            //txtInvMessage.Text        = DB.Str(dr["InvoiceMsg"]);
            //txtInvDeliveryMethod.Text = DB.Str(dr["InvDeliveryMethod"]);
            //txtInvDeliveryDate.Text   = Fmt.Dt(DB.DtTm(dr["InvDeliveryDate"]));
            //txtInvEmail.Text          = InvEmail;
            //txtInvFax.Text            = InvFax;
            //txtPaymentMsg.Text        = DB.Str(dr["PaymentMsg"]);
            //txtInvPmtDate.Text        = Fmt.Dt(DB.DtTm(dr["InvPmtDate"]));
            //txtInvPmtMethod.Text      = InvPmtMethod;
            //txtCheckRef.Text          = DB.Str(dr["CheckRef"]);
            //txtCCType.Text            = DB.Str(dr["CCType"]);
            //txtCCNum.Text             = CCNum;
            //txtCCExpDt.Text           = DB.Str(dr["CCExpDt"]);
            //txtCCSecCode.Text         = CCSecCode;
            //txtCCName.Text            = DB.Str(dr["CCName"]);
            //txtCCStreet.Text          = DB.Str(dr["CCStreet"]);
            //txtCCZip.Text             = DB.Str(dr["CCZip"]);
            //txtCCBatchID.Text         = DB.Str(dr["CCBatchID"]);
            //txtCCInvNum.Text          = DB.Str(dr["CCInvNum"]);
            //txtCCApprCode.Text        = DB.Str(dr["CCApprCode"]);
            //txtCCAVSResp.Text         = DB.Str(dr["CCAVSResp"]);
            //txtCCSettleDate.Text      = Fmt.Dt(DB.DtTm(dr["CCSettleDtTm"]));
            //chkFailedFlg.Checked      = DB.Bool(dr["CCFailedFlg"]);
            //txtFailedMsg.Text         = DB.Str(dr["CCFailedMsg"]);

            txtDepositAmt.Text = 
            hfDepositAmt.Value = Fmt.Dollar(DepositAmt, false);

			lblPmtType1.Text    = PmtType1;
			txtPmtAmtDisp1.Text = Fmt.Dollar(PmtAmt1, false);
			lblPmtRef1.Text     = PmtRef1;
			txtPmtAmt1.Value    = PmtAmt1.ToString();
			txtPmtType1.Value   = PmtType1;
			txtPmtRef1.Value    = PmtRef1;
			txtPmtDt1.Value     = Fmt.Dt(PmtDt1);
			txtPmtMethod1.Value = PmtMethod1;
            txtCCStatus1.Value  = CCStatus1;   
            txtCCAuth1.Value    = CCAuth1;
            txtCCResult1.Value  = CCResult1;
   //         txtCCReqAmt1.Value  = CCReqAmt1.ToString();
			//txtCCType1.Value    = CCType1;
			//txtCCNum1.Value     = CCNum1;
			//txtCCExpDt1.Value   = CCExpDt1;
			//txtCCSecCode1.Value = CCSecCode1;
			//txtCCName1.Value    = CCName1;
			//txtCCAddr1.Value    = CCAddr1;
			//txtCCZip1.Value     = CCZip1;

			lblPmtType2.Text    = PmtType2;
			txtPmtAmtDisp2.Text = Fmt.Dollar(PmtAmt2, false);
			lblPmtRef2.Text     = PmtRef2;
			txtPmtAmt2.Value    = PmtAmt2.ToString();
			txtPmtType2.Value   = PmtType2;
			txtPmtRef2.Value    = PmtRef2;
			txtPmtDt2.Value     = Fmt.Dt(PmtDt2);
			txtPmtMethod2.Value = PmtMethod2;
            txtCCStatus2.Value  = CCStatus2;
            txtCCAuth2.Value    = CCAuth2;
            txtCCResult2.Value  = CCResult2;
			//txtCCReqAmt2.Value  = CCReqAmt2.ToString();
			//txtCCType2.Value    = CCType2;
			//txtCCNum2.Value     = CCNum2;
			//txtCCExpDt2.Value   = CCExpDt2;
			//txtCCSecCode2.Value = CCSecCode2;
			//txtCCName2.Value    = CCName2;
			//txtCCAddr2.Value    = CCAddr2;
			//txtCCZip2.Value     = CCZip2;

			lblPmtType3.Text    = PmtType3;
			txtPmtAmtDisp3.Text = Fmt.Dollar(PmtAmt3, false);
			lblPmtRef3.Text     = PmtRef3;
			txtPmtAmt3.Value    = PmtAmt3.ToString();
			txtPmtType3.Value   = PmtType3;
			txtPmtRef3.Value    = PmtRef3;
			txtPmtDt3.Value     = Fmt.Dt(PmtDt3);
			txtPmtMethod3.Value = PmtMethod3;
            txtCCStatus3.Value  = CCStatus3;
            txtCCAuth3.Value    = CCAuth3;
            txtCCResult3.Value  = CCResult3;
			//txtCCReqAmt3.Value  = CCReqAmt3.ToString();
			//txtCCType3.Value    = CCType3;
			//txtCCNum3.Value     = CCNum3;
			//txtCCExpDt3.Value   = CCExpDt3;
			//txtCCSecCode3.Value = CCSecCode3;
			//txtCCName3.Value    = CCName3;
			//txtCCAddr3.Value    = CCAddr3;
			//txtCCZip3.Value     = CCZip3;

			//decimal CCFeeAmt = 0;
			//if (PmtMethod1 == CreditCard)
			//{
			//	CCFeeAmt += Math.Round(CCReqAmt1 * CCFeePct / 100, 2);
			//}
			//if (PmtMethod2 == CreditCard)
			//{
			//	CCFeeAmt += Math.Round(CCReqAmt2 * CCFeePct / 100, 2);
			//}
			//if (PmtMethod3 == CreditCard)
			//{
			//	CCFeeAmt += Math.Round(CCReqAmt3 * CCFeePct / 100, 2);
			//}
			decimal CCFeeAmt = DB.Dec(dr["CCFeeAmt"]);
			if (CCFeeAmt != 0)
				fChargeCCFee    = true;
			txtCCFeeAmt.Text    = Fmt.Dollar(CCFeeAmt);
			txtCCFeePct.Text    = Fmt.Pct(CCFeePct, 3, false);
			txtCCFeeTaxPct.Text = Fmt.Pct(CCFeeTaxPct, 3, false);

			txtInvCreatedDt.Text            = Fmt.DtTm(DB.DtTm(dr["InvCreatedDtTm"]));
			txtInvCreatedUser.Text          = DB.Str(dr["InvCreatedUser"]);
			txtInvUpdatedDt.Text            = Fmt.DtTm(DB.DtTm(dr["InvUpdatedDtTm"]));
			txtInvUpdatedUser.Text          = DB.Str(dr["InvUpdatedUser"]);
            txtDepositInvPrintedDtTm.Text   = Fmt.DtTm(DB.DtTm(dr["DepositInvPrintedDtTm"]));
            txtDepositInvPrintedUser.Text   = DB.Str(dr["DepositInvPrintedUser"]);
            txtDepositInvEmailedDtTm.Text   = Fmt.DtTm(DB.DtTm(dr["DepositInvEmailedDtTm"]));
            txtDepositInvEmailedUser.Text   = DB.Str(dr["DepositInvEmailedUser"]);
            lblSaveDt.Text                  = (txtInvUpdatedDt.Text.Length > 0 ? txtInvUpdatedDt.Text : txtInvCreatedDt.Text);
			lblSaveFinalDt.Text             = Fmt.DtTm(DB.DtTm(dr["FinalDtTm"]));
			lblPrintDt.Text                 = Fmt.DtTm(DB.DtTm(dr["InvoicedDtTm"]));
			lblEmailDt.Text                 = Fmt.DtTm(DB.DtTm(dr["InvEmailedDtTm"]));
            lblDepositDt.Text               = Fmt.DtTm(Misc.Max(DB.DtTm(dr["DepositInvPrintedDtTm"]), DB.DtTm(dr["DepositInvEmailedDtTm"])));

            txtEmail.Text   = DB.Str(dr["ContactEmail"]);
			txtSubject.Text = "Invoice from Marvellous Catering";
			txtMessage.Text = "Please see the attached invoice from Marvellous Catering.\n\nWe appreciate your business.";

			PctAmt(
				InvSubTotal,
				ServiceSubTotPctFlg,
				ServiceSubTotPct,
				ref ServiceAmt,
				ref txtServiceSubTotPctFlg,
				ref txtServiceSubTotPct,
				ref txtServiceAmt);
			PctAmt(
				InvSubTotal,
				DeliverySubTotPctFlg,
				DeliverySubTotPct,
				ref DeliveryAmt,
				ref txtDeliverySubTotPctFlg,
				ref txtDeliverySubTotPct,
				ref txtDeliveryAmt);
			PctAmt(
				InvSubTotal,
				ChinaSubTotPctFlg,
				ChinaSubTotPct,
				ref ChinaAmt,
				ref txtChinaSubTotPctFlg,
				ref txtChinaSubTotPct,
				ref txtChinaAmt);
			PctAmt(
				InvSubTotal,
				AddServiceSubTotPctFlg,
				AddServiceSubTotPct,
				ref AddServiceAmt,
				ref txtAddServiceSubTotPctFlg,
				ref txtAddServiceSubTotPct,
				ref txtAddServiceAmt);
			PctAmt(
				InvSubTotal,
				FuelTravelSubTotPctFlg,
				FuelTravelSubTotPct,
				ref FuelTravelAmt,
				ref txtFuelTravelSubTotPctFlg,
				ref txtFuelTravelSubTotPct,
				ref txtFuelTravelAmt);
			PctAmt(
				InvSubTotal,
				FacilitySubTotPctFlg,
				FacilitySubTotPct,
				ref FacilityAmt,
				ref txtFacilitySubTotPctFlg,
				ref txtFacilitySubTotPct,
				ref txtFacilityAmt);
            PctAmt(
                InvSubTotal,
                GratuitySubTotPctFlg,
                GratuitySubTotPct,
                ref GratuityAmt,
                ref txtGratuitySubTotPctFlg,
                ref txtGratuitySubTotPct,
                ref txtGratuityAmt);
			PctAmt(
				InvSubTotal,
				RentalsSubTotPctFlg,
				RentalsSubTotPct,
				ref RentalsAmt,
				ref txtRentalsSubTotPctFlg,
				ref txtRentalsSubTotPct,
				ref txtRentalsAmt);
			PctAmt(
				InvSubTotal,
				DB.Bool(dr["Adj1SubTotPctFlg"]),
				DB.Dec(dr["Adj1SubTotPct"]),
				ref Adj1Amt,
				ref txtAdj1SubTotPctFlg,
				ref txtAdj1SubTotPct,
				ref txtAdj1Amt);
			PctAmt(
				InvSubTotal,
				DB.Bool(dr["Adj2SubTotPctFlg"]),
				DB.Dec(dr["Adj2SubTotPct"]),
				ref Adj2Amt,
				ref txtAdj2SubTotPctFlg,
				ref txtAdj2SubTotPct,
				ref txtAdj2Amt);

			//decimal PreTaxTotal =
			//	InvSubTotal +
			//	ServiceAmt +
			//	DeliveryAmt +
			//	ChinaAmt +
			//	AddServiceAmt +
			//	FuelTravelAmt +
			//	FacilityAmt +
			//	GratuityAmt +
			//	RentalsAmt +
			//	Adj1Amt +
			//	Adj2Amt +
			//	CCFeeAmt;

			//decimal SalesTaxTotal =
			//	InvSubTotal   * SubTotTaxPct		/ 100 +
			//	ServiceAmt    * ServiceTaxPct		/ 100 +
			//	DeliveryAmt   * DeliveryTaxPct		/ 100 +
			//	ChinaAmt      * ChinaTaxPct			/ 100 +
			//	AddServiceAmt * AddServiceTaxPct	/ 100 +
			//	FuelTravelAmt * FuelTravelTaxPct	/ 100 +
			//	FacilityAmt   * FacilityTaxPct		/ 100 +
			//	GratuityAmt   * GratuityTaxPct		/ 100 +
			//	RentalsAmt    * RentalsTaxPct		/ 100 +
			//	Adj1Amt       * Adj1TaxPct			/ 100 +
			//	Adj2Amt       * Adj2TaxPct			/ 100 +
			//	CCFeeAmt      * CCFeeTaxPct			/ 100;

			//decimal InvTotal   = PreTaxTotal + SalesTaxTotal;
			//decimal InvBalance = InvTotal + PmtAmt1 + PmtAmt2 + PmtAmt3;

			decimal PreTaxTotal     = DB.Dec(dr["PreTaxSubTotAmt"]);
			txtPreTaxTotal.Text     = Fmt.Dollar(PreTaxTotal, false);
			decimal SalesTaxTotal   = DB.Dec(dr["SalesTaxTotAmt"]);
			txtSalesTaxTotal.Text   = Fmt.Dollar(SalesTaxTotal, false);
			decimal InvTotal        = DB.Dec(dr["InvTotAmt"]);
			txtInvTotal.Text        = Fmt.Dollar(InvTotal, false);
			decimal InvBalance      = DB.Dec(dr["InvBalAmt"]);
			txtInvBalance.Text      = Fmt.Dollar(InvBalance, false);

			if (txtInvDate.Text.Length > 0)
			{
				calInvDate.Date = Str.DtTm(txtInvDate.Text);
			}

			string txtInvoicedDt = Fmt.Dt(DB.DtTm(dr["InvoicedDtTm"]));
			fPrinted = (txtInvoicedDt.Length > 0);

			if (txtAdj1Desc.Text.Length == 0 && txtInvCreatedDt.Text.Length == 0)
			{
				txtAdj1Desc.Text =
				txtAdj2Desc.Text = "Adjustment";
			}

			if (dtInvEmailed != DateTime.MinValue)
			{
				btnEmail.Value = "Re-Email";
			}

            DefaultServings = DB.Int32(dr["NumMenServing"]) + DB.Int32(dr["NumWomenServing"]) + DB.Int32(dr["NumChildServing"]);
		}
	}

	private decimal AdditionalPrices(int InvEventCount, decimal InvPricePerPerson, decimal SubTotTaxPct)
	{
		decimal Subtotal = 0;
		StringBuilder sb = new StringBuilder();
		int iPrice = 0;

		string Sql = "Select * From JobInvoicePrices Where JobRno = " + JobRno + " Order By Seq, CreatedDtTm";
		DataTable dtPrices = db.DataTable(Sql);

		if (dtPrices.Rows.Count == 0)
		{
			//InsertPrice(Misc.cnPerPerson, InvEventCount, "servings", InvPricePerPerson);
			//dtPrices = db.DataTable(Sql);

			DataRow dr = dtPrices.NewRow();
			dr["PriceType"] = Misc.cnPerPerson;
			dr["InvPerPersonCount"] = InvEventCount;
			dr["InvPerPersonDesc"] = "servings";
			dr["InvPerPersonPrice"] = InvPricePerPerson;
			dr["InvPerPersonExtPrice"] = InvEventCount * InvPricePerPerson;

			dtPrices.Rows.Add(dr);
		}

		foreach (DataRow drPrice in dtPrices.Rows)
		{
			string PriceType = DB.Str(drPrice["PriceType"]);
			int Count = 0;
			decimal Price = 0;
			decimal ExtPrice = 0;
			string Desc = "";
			string ExtDesc = "";

			switch (PriceType)
			{
				case Misc.cnPerPerson:
					Count = DB.Int32(drPrice["InvPerPersonCount"]);
					Price = DB.Dec(drPrice["InvPerPersonPrice"]);
					//ExtPrice = Count * Price;
					ExtPrice = DB.Dec(drPrice["InvPerPersonExtPrice"]);
					Desc = DB.Str(drPrice["InvPerPersonDesc"]);
					ExtDesc = string.Format("{0} {1} @ {2} per person",
						Fmt.Num(Count),
						Desc,
						Fmt.Dollar(Price));
					break;

				case Misc.cnPerItem:
					Count = DB.Int32(drPrice["InvPerItemCount"]);
					Price = DB.Dec(drPrice["InvPerItemPrice"]);
					//ExtPrice = Count * Price;
					ExtPrice = DB.Dec(drPrice["InvPerItemExtPrice"]);
					Desc = DB.Str(drPrice["InvPerItemDesc"]);
					ExtDesc = string.Format("{0} {1} @ {2} per item",
						Fmt.Num(Count),
						Desc,
						Fmt.Dollar(Price));
					break;

				case Misc.cnAllIncl:
					Count = 1;
					Price = DB.Dec(drPrice["InvAllInclPrice"]);
					//ExtPrice = Price - (Price * (1 - 1 / (1 + SubTotTaxPct / 100)));
					ExtPrice = DB.Dec(drPrice["InvAllInclExtPrice"]);
					Desc = DB.Str(drPrice["InvAllInclDesc"]);
					ExtDesc = string.Format("All inclusive {0} @ {1}",
						Desc,
						Fmt.Dollar(Price));
					break;

				default:
					break;
			}
			int Rno = DB.Int32(drPrice["Rno"]);
			sb.AppendFormat(
				"<tr>\n" +
				"<td colspan=\"3\" align=\"right\" class=\"ExtDesc\">{1}</td>\n<td></td>\n" +
				"<td><input type=\"text\" value=\"{2}\" disabled=\"disabled\" class=\"JobSubTotal DispExtPrice\" /></td>\n<td></td>\n" +
				"<td>\n" +
				"<img src=\"Images/Notepage16.png\" class=\"EditPrice\" alt=\"Edit Price\" title=\"Edit Price\" />\n" +
				"<img src=\"Images/Delete16.png\" class=\"DeletePrice\" alt=\"Delete Price\" title=\"Delete Price\" />\n" +
				"<input type=\"hidden\" name=\"Seq{0}\" value=\"{0}\" class=\"Seq\" />\n" +
				"<input type=\"hidden\" name=\"Rno{0}\" value=\"{3}\" class=\"Rno\" />\n" +
				"<input type=\"hidden\" name=\"PriceType{0}\" value=\"{4}\" class=\"PriceType\" />\n" +
				"<input type=\"hidden\" name=\"Count{0}\" value=\"{5}\" class=\"Count\" />\n" +
				"<input type=\"hidden\" name=\"Price{0}\" value=\"{6}\" class=\"Price\" />\n" +
				"<input type=\"hidden\" name=\"ExtPrice{0}\" value=\"{7}\" class=\"ExtPrice\" />\n" +
				"<input type=\"hidden\" name=\"Desc{0}\" value=\"{8}\" class=\"Desc\" />\n" +
				"<input type=\"hidden\" name=\"Delete{0}\" value=\"0\" class=\"Delete\" />\n" +
				"</td>\n" +
				"</tr>\n",
				++iPrice,
				ExtDesc,
				Fmt.Dollar(ExtPrice),
				(Rno > 0 ? Rno.ToString() : ""),
				DB.Str(drPrice["PriceType"]),
				Count,
				Fmt.Dollar(Price),
				ExtPrice,
				Desc);
			Subtotal += ExtPrice;
		}

		sb.AppendFormat(
			"<input type=\"hidden\" id=\"PriceNum\" value=\"{0}\" />\n",
			iPrice);

		ltlPricing.Text = sb.ToString();

		return Subtotal;
	}

	private string Decrypt(string Value)
	{
		if (Value.Length > 0)
		{
			try
			{
				Value = Crypt.Decrypt(Value, Misc.Password);
			}
			catch (Exception)
			{
			}
		}

		return Value;
	}

	private void PctAmt(
		decimal SubTotal,
		bool PctFlg,
		decimal Pct,
		ref decimal Amt,
		ref HtmlInputHidden txtPctFlg,
		ref TextBox txtPct,
		ref TextBox txtAmt)
	{
		if (PctFlg)
		{
			Amt = Math.Round(SubTotal * Pct / 100, 2);
		}
		else
		{
			if (SubTotal != 0)
			{
				Pct = Amt / SubTotal * 100;
			}
		}

		txtPctFlg.Value = (PctFlg ? "true" : "false");
		txtPct.Text = Fmt.Pct(Pct, 3, false);
		txtAmt.Text = Fmt.Dollar(Amt, false);
	}

	private void SaveValues()
	{
		string Sql = "";

		try
		{
			Sql = "Select InvCreatedDtTm From mcJobs Where JobRno = " + JobRno;
			fNew = (Fmt.DtTm(DB.DtTm(db.SqlDtTm(Sql))) == "");

			string sCreatedUpdated = (fNew ? "Created" : "Updated");
			string sInvDtTm = "Inv" + sCreatedUpdated + "DtTm";
			string sInvUser = "Inv" + sCreatedUpdated + "User";

			DateTime Tm = DateTime.Now;

			Sql =
				"Update mcJobs Set "        +
				"TaxExemptFlg = "           + DB.PutBool(chkSalesTaxExempt.Checked) + ", " +
				"InvDate = "                + DB.PutDtTm(Str.DtTm(txtInvDate.Text)) + ", " +
				//"InvEventCount = "        + Str.Num(txtInvEventCount.Text) + ", " +
				//"InvPricePerPerson = "    + Str.Dec(txtInvPricePerPerson.Text) + ", " +
				"InvEventCount = 0, "       +
				"InvPricePerPerson = 0, "   + 
				"SubTotAmt = "              + Str.Dec(hfInvSubTotal.Value) + ", " +
				"SubTotTaxPct = "           + Str.Dec(txtSubTotTaxPct.Text) + ", " +
				"ServiceSubTotPctFlg = "    + DB.PutBool(txtServiceSubTotPctFlg.Value == "true") + ", " +
				"ServiceSubTotPct = "       + Str.Dec(txtServiceSubTotPct.Text) + ", " +
				"ServiceAmt = "             + Str.Dec(txtServiceAmt.Text) + ", " +
				"ServiceTaxPct = "          + Str.Dec(txtServiceTaxPct.Text) + ", " +
				"DeliverySubTotPctFlg = "   + DB.PutBool(txtDeliverySubTotPctFlg.Value == "true") + ", " +
				"DeliverySubTotPct = "      + Str.Dec(txtDeliverySubTotPct.Text) + ", " +
				"DeliveryAmt = "            + Str.Dec(txtDeliveryAmt.Text) + ", " +
				"DeliveryTaxPct = "         + Str.Dec(txtDeliveryTaxPct.Text) + ", " +
				"ChinaSubTotPctFlg = "      + DB.PutBool(txtChinaSubTotPctFlg.Value == "true") + ", " +
				"ChinaSubTotPct = "         + Str.Dec(txtChinaSubTotPct.Text) + ", " +
				"ChinaAmt = "               + Str.Dec(txtChinaAmt.Text) + ", " +
				"ChinaTaxPct = "            + Str.Dec(txtChinaTaxPct.Text) + ", " +
				"AddServiceSubTotPctFlg = " + DB.PutBool(txtAddServiceSubTotPctFlg.Value == "true") + ", " +
				"AddServiceSubTotPct = "    + Str.Dec(txtAddServiceSubTotPct.Text) + ", " +
				"AddServiceAmt = "          + Str.Dec(txtAddServiceAmt.Text) + ", " +
				"AddServiceTaxPct = "       + Str.Dec(txtAddServiceTaxPct.Text) + ", " +
				"FuelTravelSubTotPctFlg = " + DB.PutBool(txtFuelTravelSubTotPctFlg.Value == "true") + ", " +
				"FuelTravelSubTotPct = "    + Str.Dec(txtFuelTravelSubTotPct.Text) + ", " +
				"FuelTravelAmt = "          + Str.Dec(txtFuelTravelAmt.Text) + ", " +
				"FuelTravelTaxPct = "       + Str.Dec(txtFuelTravelTaxPct.Text) + ", " +
				"FacilitySubTotPctFlg = "   + DB.PutBool(txtFacilitySubTotPctFlg.Value == "true") + ", " +
				"FacilitySubTotPct = "      + Str.Dec(txtFacilitySubTotPct.Text) + ", " +
				"FacilityAmt = "            + Str.Dec(txtFacilityAmt.Text) + ", " +
				"FacilityTaxPct = "         + Str.Dec(txtFacilityTaxPct.Text) + ", " +
				"GratuitySubTotPctFlg = "   + DB.PutBool(txtGratuitySubTotPctFlg.Value == "true") + ", " +
				"GratuitySubTotPct = "      + Str.Dec(txtGratuitySubTotPct.Text) + ", " +
				"GratuityAmt = "            + Str.Dec(txtGratuityAmt.Text) + ", " +
				//"GratuityTaxPct = "       + Str.Dec(txtGratuityTaxPct.Text) + ", " +
				"RentalsSubTotPctFlg = "    + DB.PutBool(txtRentalsSubTotPctFlg.Value == "true") + ", " +
				"RentalsSubTotPct = "       + Str.Dec(txtRentalsSubTotPct.Text) + ", " +
				"RentalsAmt = "             + Str.Dec(txtRentalsAmt.Text) + ", " +
				"RentalsTaxPct = "          + Str.Dec(txtRentalsTaxPct.Text) + ", " +
				"RentalsDesc = "            + DB.PutStr(txtRentalsDesc.Text) + ", " +
				"Adj1SubTotPctFlg = "       + DB.PutBool(txtAdj1SubTotPctFlg.Value == "true") + ", " +
				"Adj1SubTotPct = "          + Str.Dec(txtAdj1SubTotPct.Text) + ", " +
				"Adj1Desc = "               + DB.PutStr(txtAdj1Desc.Text, 50) + ", " +
				"Adj1Amt = "                + Str.Dec(txtAdj1Amt.Text) + ", " +
				"Adj1TaxPct = "             + Str.Dec(txtAdj1TaxPct.Text) + ", " +
				"Adj2SubTotPctFlg = "       + DB.PutBool(txtAdj2SubTotPctFlg.Value == "true") + ", " +
				"Adj2SubTotPct = "          + Str.Dec(txtAdj2SubTotPct.Text) + ", " +
				"Adj2Desc = "               + DB.PutStr(txtAdj2Desc.Text, 50) + ", " +
				"Adj2Amt = "                + Str.Dec(txtAdj2Amt.Text) + ", " +
				"Adj2TaxPct = "             + Str.Dec(txtAdj2TaxPct.Text) + ", " +
				//"InvoiceMsg = "           + DB.PutStr(txtInvMessage.Text, 200) + ", " +
				//"InvDeliveryMethod = "    + DB.PutStr(txtInvDeliveryMethod.Text, 20) + ", " +
				//"InvDeliveryDate = "      + DB.PutDtTm(Str.DtTm(txtInvDeliveryDate.Text)) + ", " +
				//"InvEmail = "             + DB.PutStr(txtInvEmail.Text, 80) + ", " +
				//"InvFax = "               + DB.PutStr(txtInvFax.Text, 30) + ", " +
				//"DepAmt = "               + Str.Dec(txtDepositAmt.Text) + ", " +
				//"DepDtTm = "              + DB.PutDtTm(Str.DtTm(txtDepositDate.Text)) + ", " +
				//"DepRef = "               + DB.PutStr(txtDepositRef.Text, 30) + ", " +
				//"PaymentMsg = "           + DB.PutStr(txtPaymentMsg.Text, 200) + ", " +
				//"InvPmtDate = "           + DB.PutDtTm(Str.DtTm(txtInvPmtDate.Text)) + ", " +
				//"InvPmtMethod = "         + DB.PutStr(txtInvPmtMethod.Text, 20) + ", " +
				//"CheckRef = "             + DB.PutStr(txtCheckRef.Text, 50) + ", " +
				//"CCType = "               + DB.PutStr(txtCCType.Text, 20) + ", " +
				//"CCNum = "                + DB.PutStr((txtCCNum.Text.Length > 0 ? Crypt.Encrypt(txtCCNum.Text, Misc.Password) : null), 100) + ", " +
				//"CCExpDt = "              + DB.PutStr(txtCCExpDt.Text, 6) + ", " +
				//"CCSecCode = "            + DB.PutStr((txtCCSecCode.Text.Length > 0 ? Crypt.Encrypt(txtCCSecCode.Text, Misc.Password) : null), 50) + ", " +
				//"CCName = "               + DB.PutStr(txtCCName.Text, 50) + ", " +
				//"CCStreet = "             + DB.PutStr(txtCCStreet.Text, 50) + ", " +
				//"CCZip = "                + DB.PutStr(txtCCZip.Text, 15) + ", " +
				//"CCBatchID = "            + DB.PutStr(txtCCBatchID.Text, 10) + ", " +
				//"CCInvNum = "             + DB.PutStr(txtCCInvNum.Text, 10) + ", " +
				//"CCApprCode = "           + DB.PutStr(txtCCApprCode.Text, 10) + ", " +
				//"CCAVSResp = "            + DB.PutStr(txtCCAVSResp.Text, 10) + ", " +
				//"CCSettleDtTm = "         + DB.PutDtTm(Str.DtTm(txtCCSettleDate.Text)) + ", " +
				//"CCFailedFlg = "          + DB.PutBool(chkFailedFlg.Checked) + ", " +
				//"CCFailedMsg = "          + DB.PutStr(txtFailedMsg.Text, 50) + ", " +
                "DepositAmt = "             + Str.Dec(hfDepositAmt.Value) + ", " +
				"PmtType1 = "               + DB.PutStr(txtPmtType1.Value, 12) + ", " + 
                "PmtAmt1 = "                + Str.Dec(txtPmtAmt1.Value) + ", " +
				"PmtDt1 = "                 + DB.PutDtTm(Str.DtTm(txtPmtDt1.Value)) + ", " +
				"PmtRef1 = "                + DB.PutStr(txtPmtRef1.Value, 130) + ", " +
				"PmtMethod1 = "             + DB.PutStr(txtPmtMethod1.Value, 12) + ", " + 
                "CCStatus1 = "              + DB.PutStr(txtCCStatus1.Value, 30) + ", " +
                "CCAuth1 = "                + DB.PutStr(txtCCAuth1.Value, 50) + ", " +
                "CCResult1 = "              + DB.PutStr(txtCCResult1.Value, 10) + ", " +
				//"CCReqAmt1 = "              + Str.Dec(txtCCReqAmt1.Value) + ", " +
				//"CCType1 = "                + DB.PutStr(txtCCType1.Value, 20) + ", " +
				//"CCNum1 = "                 + DB.PutStr((txtCCNum1.Value.Length > 0 ? Crypt.Encrypt(txtCCNum1.Value, Misc.Password) : null), 100) + ", " + 
				//"CCExpDt1 = "               + DB.PutStr(txtCCExpDt1.Value, 6) + ", " +
				//"CCSecCode1 = "             + DB.PutStr((txtCCSecCode1.Value.Length > 0 ? Crypt.Encrypt(txtCCSecCode1.Value, Misc.Password) : null), 50) + ", " + 
				//"CCName1 = "                + DB.PutStr(txtCCName1.Value, 50) + ", " + 
				//"CCAddr1 = "                + DB.PutStr(txtCCAddr1.Value, 50) + ", " +
				//"CCZip1 = "                 + DB.PutStr(txtCCZip1.Value, 15) + ", " +
				"PmtType2 = "               + DB.PutStr(txtPmtType2.Value, 12) + ", " +
				"PmtAmt2 = "                + Str.Dec(txtPmtAmt2.Value) + ", " +
				"PmtDt2 = "                 + DB.PutDtTm(Str.DtTm(txtPmtDt2.Value)) + ", " +
				"PmtRef2 = "                + DB.PutStr(txtPmtRef2.Value, 130) + ", " +
				"PmtMethod2 = "             + DB.PutStr(txtPmtMethod2.Value, 12) + ", " +
                "CCStatus2 = "              + DB.PutStr(txtCCStatus2.Value, 30) + ", " +
                "CCAuth2 = "                + DB.PutStr(txtCCAuth2.Value, 50) + ", " +
                "CCResult2 = "              + DB.PutStr(txtCCResult2.Value, 10) + ", " +
				//"CCReqAmt2 = "              + Str.Dec(txtCCReqAmt2.Value) + ", " +
				//"CCType2 = "                + DB.PutStr(txtCCType2.Value, 20) + ", " +
				//"CCNum2 = "                 + DB.PutStr((txtCCNum2.Value.Length > 0 ? Crypt.Encrypt(txtCCNum2.Value, Misc.Password) : null), 100) + ", " +
				//"CCExpDt2 = "               + DB.PutStr(txtCCExpDt2.Value, 6) + ", " +
				//"CCSecCode2 = "             + DB.PutStr((txtCCSecCode2.Value.Length > 0 ? Crypt.Encrypt(txtCCSecCode2.Value, Misc.Password) : null), 50) + ", " +
				//"CCName2 = "                + DB.PutStr(txtCCName2.Value, 50) + ", " +
				//"CCAddr2 = "                + DB.PutStr(txtCCAddr2.Value, 50) + ", " +
				//"CCZip2 = "                 + DB.PutStr(txtCCZip2.Value, 15) + ", " +
				"PmtType3 = "               + DB.PutStr(txtPmtType3.Value, 12) + ", " +
				"PmtAmt3 = "                + Str.Dec(txtPmtAmt3.Value) + ", " +
				"PmtDt3 = "                 + DB.PutDtTm(Str.DtTm(txtPmtDt3.Value)) + ", " +
				"PmtRef3 = "                + DB.PutStr(txtPmtRef3.Value, 130) + ", " +
				"PmtMethod3 = "             + DB.PutStr(txtPmtMethod3.Value, 12) + ", " +
                "CCStatus3 = "              + DB.PutStr(txtCCStatus3.Value, 30) + ", " +
                "CCAuth3 = "                + DB.PutStr(txtCCAuth3.Value, 50) + ", " +
                "CCResult3 = "              + DB.PutStr(txtCCResult3.Value, 10) + ", " +
				//"CCReqAmt3 = "              + Str.Dec(txtCCReqAmt3.Value) + ", " +
				//"CCType3 = "                + DB.PutStr(txtCCType3.Value, 20) + ", " +
				//"CCNum3 = "                 + DB.PutStr((txtCCNum3.Value.Length > 0 ? Crypt.Encrypt(txtCCNum3.Value, Misc.Password) : null), 100) + ", " +
				//"CCExpDt3 = "               + DB.PutStr(txtCCExpDt3.Value, 6) + ", " +
				//"CCSecCode3 = "             + DB.PutStr((txtCCSecCode3.Value.Length > 0 ? Crypt.Encrypt(txtCCSecCode3.Value, Misc.Password) : null), 50) + ", " +
				//"CCName3 = "                + DB.PutStr(txtCCName3.Value, 50) + ", " +
				//"CCAddr3 = "                + DB.PutStr(txtCCAddr3.Value, 50) + ", " +
				//"CCZip3 = "                 + DB.PutStr(txtCCZip3.Value, 15) + ", " +
				"CCPmtFeeFlg = "            + DB.PutBool(chkCCPmtFee.Checked) + ", " + 
				"CCFeePct = "               + Str.Dec(txtCCFeePct.Text) + ", " +
				"CCFeeAmt = "               + Str.Dec(hfCCFeeAmt.Value) + ", " +
				"CCFeeTaxPct = "            + Str.Dec(txtCCFeeTaxPct.Text) + ", " +
				"PreTaxSubTotAmt = "        + Str.Dec(hfPreTaxTotal.Value) + ", " +
				"SalesTaxTotAmt = "         + Str.Dec(hfSalesTaxTotal.Value) + ", " +
				"InvTotAmt = "              + Str.Dec(hfInvTotal.Value) + ", " +
				"InvBalAmt = "              + Str.Dec(hfInvBalance.Value) + ", " +
				sInvDtTm + " = "            + DB.PutDtTm(Tm) + ", " +
				sInvUser + " = "            + DB.PutStr(g.User) + " " +
				"Where JobRno = "           + JobRno;
			db.Exec(Sql);

			SaveAdditionalPrices();

			SaveFinal(Tm);
		}
		catch (Exception Ex)
		{
			Err Err = new Err(Ex, Sql);
			Response.Write(Err.Html());
		}
	}

	private void SaveAdditionalPrices()
	{
		int iPrice = 0;
		string Sql = "";
		DateTime Tm = DateTime.Now;

		try
		{
			while (Page.Request.Params["Rno" + (++iPrice)] != null)
			{
				string Rno = Page.Request.Params["Rno" + iPrice];

				if (Rno.Length == 0)
				{
					// insert
					if (Page.Request.Params["Delete" + iPrice] == "0")
					{
						InsertPrice(
							Page.Request.Params["PriceType" + iPrice],
							Str.Num(Page.Request.Params["Count" + iPrice]),
							Page.Request.Params["Desc" + iPrice],
							Str.Dec(Page.Request.Params["Price" + iPrice]),
							Str.Dec(Page.Request.Params["ExtPrice" + iPrice]));
						//int nRno = db.NextRno("JobInvoicePrices", "Rno");
						//Sql = "Insert Into JobInvoicePrices (Rno, JobRno, Seq, PriceType, " +
						//    "InvPerPersonCount, InvPerPersonDesc, InvPerPersonPrice, " +
						//    "InvPerItemCount, InvPerItemDesc, InvPerItemPrice, " +
						//    "InvAllInclDesc, InvAllInclPrice, " +
						//    "CreatedDtTm, CreatedUser, UpdatedDtTm, UpdatedUser) Values (" +
						//    nRno + ", " +
						//    JobRno + ", " +
						//    db.NextSeq("JobInvoicePrices", "JobRno", JobRno, "Seq") + ", " +
						//    DB.PutStr(Page.Request.Params["PriceType" + iPrice], 20) + ", " +
						//    Str.Num(Page.Request.Params["Count" + iPrice]) + ", " +
						//    DB.PutStr(Page.Request.Params["Desc" + iPrice], 50) + ", " +
						//    Str.Dec(Page.Request.Params["Price" + iPrice]) + ", " +
						//    Str.Num(Page.Request.Params["Count" + iPrice]) + ", " +
						//    DB.PutStr(Page.Request.Params["Desc" + iPrice], 50) + ", " +
						//    Str.Dec(Page.Request.Params["Price" + iPrice]) + ", " +
						//    DB.PutStr(Page.Request.Params["Desc" + iPrice], 50) + ", " +
						//    Str.Dec(Page.Request.Params["Price" + iPrice]) + ", " +
						//    DB.PutDtTm(Tm) + ", " +
						//    DB.PutStr(g.User) + ", " +
						//    DB.PutDtTm(Tm) + ", " +
						//    DB.PutStr(g.User) + ")";
						//db.Exec(Sql);
					}
					else
					{
						// delete - do nothing
					}
				}
				else
				{
					// update
					if (Page.Request.Params["Delete" + iPrice] == "0")
					{
						Sql = "Update JobInvoicePrices Set " +
							"PriceType = "              + DB.PutStr(Page.Request.Params["PriceType" + iPrice], 20) + ", " +
							"InvPerPersonCount = "      + Str.Num(Page.Request.Params["Count" + iPrice]) + ", " +
							"InvPerPersonDesc = "       + DB.PutStr(Page.Request.Params["Desc" + iPrice], 50) + ", " +
							"InvPerPersonPrice = "      + Str.Dec(Page.Request.Params["Price" + iPrice]) + ", " +
							"InvPerPersonExtPrice = "   + Str.Dec(Page.Request.Params["ExtPrice" + iPrice]) + ", " +
							"InvPerItemCount = "        + Str.Num(Page.Request.Params["Count" + iPrice]) + ", " +
							"InvPerItemDesc = "         + DB.PutStr(Page.Request.Params["Desc" + iPrice], 50) + ", " +
							"InvPerItemPrice = "        + Str.Dec(Page.Request.Params["Price" + iPrice]) + ", " +
							"InvPerItemExtPrice = "     + Str.Dec(Page.Request.Params["ExtPrice" + iPrice]) + ", " +
							"InvAllInclDesc = "         + DB.PutStr(Page.Request.Params["Desc" + iPrice], 50) + ", " +
							"InvAllInclPrice = "        + Str.Dec(Page.Request.Params["Price" + iPrice]) + ", " +
							"InvAllInclExtPrice = "     + Str.Dec(Page.Request.Params["ExtPrice" + iPrice]) + ", " +
							"UpdatedDtTm = "            + DB.PutDtTm(Tm) + ", " +
							"UpdatedUser = "            + DB.PutStr(g.User) + " " +
							"Where Rno = "              + Rno;
						db.Exec(Sql);
					}
					else
					{
						// delete
						Sql = string.Format("Delete From JobInvoicePrices Where Rno = {0}", Rno);
						db.Exec(Sql);
					}
				}
			}
		}
		catch (Exception Ex)
		{
			Err Err = new Err(Ex, Sql);
			Response.Write(Err.Html());
		}
	}

	private void InsertPrice(string PriceType, int Count, string Desc, decimal Price, decimal ExtPrice)
	{
		//string Sql = "";
		//DateTime Tm = DateTime.Now;

		//try
		//{
		//	int nRno = db.NextRno("JobInvoicePrices", "Rno");
		//	Sql = 
		//		"Insert Into JobInvoicePrices (Rno, JobRno, Seq, PriceType, " +
		//		"InvPerPersonCount, InvPerPersonDesc, InvPerPersonPrice, " +
		//		"InvPerItemCount, InvPerItemDesc, InvPerItemPrice, " +
		//		"InvAllInclDesc, InvAllInclPrice, " +
		//		"CreatedDtTm, CreatedUser, UpdatedDtTm, UpdatedUser) Values (" +
		//		nRno + ", " +
		//		JobRno + ", " +
		//		db.NextSeq("JobInvoicePrices", "JobRno", JobRno, "Seq") + ", " +
		//		DB.PutStr(PriceType, 20) + ", " +
		//		Count + ", " +
		//		DB.PutStr(Desc, 50) + ", " +
		//		Price + ", " +
		//		Count + ", " +
		//		DB.PutStr(Desc, 50) + ", " +
		//		Price + ", " +
		//		DB.PutStr(Desc, 50) + ", " +
		//		Price + ", " +
		//		DB.PutDtTm(Tm) + ", " +
		//		DB.PutStr(g.User) + ", " +
		//		DB.PutDtTm(Tm) + ", " +
		//		DB.PutStr(g.User) + ")";
		//	db.Exec(Sql);
		//}
		//catch (Exception Ex)
		//{
		//	Err Err = new Err(Ex, Sql);
		//	Response.Write(Err.Html());
		//}

		Misc.InsertPrice(db, JobRno, PriceType, Count, Desc, Price, ExtPrice);
	}

	private void SaveFinal(DateTime Tm)
	{
		if (fSaveFinal)
		{
			String Sql = "Select * From mcJobs Where JobRno = " + JobRno;
			try
			{
				DataTable tbl = db.DataTable(Sql);
				if (tbl.Rows.Count > 0)
				{
					DataRow dr = tbl.Rows[0];
					bool fSavedFinal = (dr["FinalDtTm"] != DBNull.Value);
					bool fProcessed = (dr["ProcessedDtTm"] != DBNull.Value);
					Sql = null;

					if (fSavedFinal)
					{
						if (fProcessed)
						{
							Sql =
								"EditProcessedDtTm = " + DB.PutDtTm(Tm) + ", " +
								"EditProcessedUser = " + DB.PutStr(g.User) + " ";
						}
					}
					else
					{
						Sql =
							"FinalDtTm = " + DB.PutDtTm(Tm) + ", " +
							"FinalUser = " + DB.PutStr(g.User) + " ";

						if (fProcessed)
						{
							Sql +=
								", ProcessedDtTm = Null, " +
								"ProcessedUser = Null ";
						}
					}

					if (Sql != null)
					{ 
						Sql =
							"Update mcJobs Set " + Sql + "Where JobRno = " + JobRno;
						db.Exec(Sql);
					}
				}
			}
			catch (Exception Ex)
			{
				Err Err = new Err(Ex, Sql);
				Response.Write(Err.Html());
			}
		}
	}

	private void SaveDefaults()
	{
		String Sql = "Select * From Settings Where SettingRno = 1";
		try
		{
			DataRow dr = db.DataRow(Sql);
			if (dr == null)
			{
				Sql = string.Format("Insert Into Settings (SettingRno, CreatedDtTm, CreatedUser) Values (1, '{0}', '{1}')", DateTime.Now, g.User);
				db.Exec(Sql);
			}

			Sql =
				"Update Settings Set "      +
				"SubTotTaxPct = "           + Str.Dec(txtSubTotTaxPct.Text) + ", " +
				"ServiceSubTotPct = "       + Str.Dec(txtServiceSubTotPct.Text) + ", " +
				"ServiceTaxPct = "          + Str.Dec(txtServiceTaxPct.Text) + ", " +
				"DeliverySubTotPct = "      + Str.Dec(txtDeliverySubTotPct.Text) + ", " +
				"DeliveryTaxPct = "         + Str.Dec(txtDeliveryTaxPct.Text) + ", " +
				"ChinaSubTotPct = "         + Str.Dec(txtChinaSubTotPct.Text) + ", " +
				"ChinaTaxPct = "            + Str.Dec(txtChinaTaxPct.Text) + ", " +
				"AddServiceSubTotPct = "    + Str.Dec(txtAddServiceSubTotPct.Text) + ", " +
				"AddServiceTaxPct = "       + Str.Dec(txtAddServiceTaxPct.Text) + ", " +
				"FuelTravelSubTotPct = "    + Str.Dec(txtFuelTravelSubTotPct.Text) + ", " +
				"FuelTravelTaxPct = "       + Str.Dec(txtFuelTravelTaxPct.Text) + ", " +
				"FacilitySubTotPct = "      + Str.Dec(txtFacilitySubTotPct.Text) + ", " +
				"FacilityTaxPct = "         + Str.Dec(txtFacilityTaxPct.Text) + ", " +
				"GratuitySubTotPct = "      + Str.Dec(txtGratuitySubTotPct.Text) + ", " +
				//"GratuityTaxPct = "       + Str.Dec(txtGratuityTaxPct.Text) + ", " +
				"RentalsSubTotPct = "       + Str.Dec(txtRentalsSubTotPct.Text) + ", " +
				"RentalsTaxPct = "          + Str.Dec(txtRentalsTaxPct.Text) + ", " +
				"Adj1TaxPct = "             + Str.Dec(txtAdj1TaxPct.Text) + ", " +
				"Adj2TaxPct = "             + Str.Dec(txtAdj2TaxPct.Text) + ", " +
				"CCFeePct = "               + Str.Dec(txtCCFeePct.Text) + ", " +
				"CCFeeTaxPct = "            + Str.Dec(txtCCFeeTaxPct.Text) + ", " +
				"UpdatedDtTm = "            + DB.PutDtTm(DateTime.Now) + ", " +
				"UpdatedUser = "            + DB.PutStr(g.User) + " " +
				"Where SettingRno = 1";
			db.Exec(Sql);
		}
		catch (Exception Ex)
		{
			Err Err = new Err(Ex, Sql);
			Response.Write(Err.Html());
		}
	}

	protected void btnSaveDefaults_Click(object sender, System.EventArgs e)
	{
		SaveDefaults();
	}

	protected void btnSave_Click(object sender, System.EventArgs e)
	{
		SaveValues();
		ReadValues();

	}

	protected void btnSaveFinal_Click(object sender, System.EventArgs e)
	{
		fSaveFinal = true;
		SaveValues();
		ReadValues();
	}

	protected string SetFocus()
	{
		string Focus = "";

		if (FocusField.Length > 0)
		{
			Focus = "SetFocus(\"" + FocusField + "\");";
		}

		return Focus;
	}

	protected void SendEmail()
	{
		int nTrys = 0;
        bool fDepositInvoice = Str.Bool(hfDepositInvoice.Value);
        decimal DepositAmt = Str.Dec(hfDepositAmt.Value);

	TryAgain:

		nTrys++;

		try
		{
			WebConfig wc = new WebConfig();
            MailMessage Msg = new MailMessage(Misc.CreateFromEmailAddress(g.User), txtEmail.Text);
			Msg.CC.Add(wc.Str("Email CC"));
            Msg.CC.Add(Misc.CreateFromEmailAddress(g.User));
            Msg.Subject = txtSubject.Text;
			Msg.Body = txtMessage.Text;

			MemoryStream ms = Utils.PdfFiles.Invoice(Page, JobRno, fDepositInvoice, DepositAmt);

			bool fTest = false;
			if (fTest)
			{
				FileStream fs = new FileStream(Server.MapPath(@"~/Invoice.pdf"), FileMode.Create, FileAccess.Write);
				ms.WriteTo(fs);
				fs.Close();
			}
			else
			{
				Msg.Attachments.Add(new Attachment(ms, "Invoice.pdf", "application/pdf"));
				SmtpClient Smtp = new SmtpClient();
				Smtp.Send(Msg);
			}

			ms.Close();
		}
		catch (Exception Ex)
		{
			if (nTrys <= 3) goto TryAgain;
			Err Err = new Err(Ex);
			Response.Write(Err.Html());
		}

		string Sql = "Select InvEmailedDtTm From mcJobs Where JobRno = " + JobRno; 
		try
		{
			DateTime dtInvEmailed = db.SqlDtTm(Sql);
			if (dtInvEmailed == DateTime.MinValue)
			{
				Sql = string.Format("Update mcJobs Set InvEmailedDtTm = GetDate(), InvEmailedUser = '{1}' Where JobRno = {0}", JobRno, g.User);
				db.Exec(Sql);
			}

            if (fDepositInvoice)
            {
                Sql = string.Format("Update mcJobs Set DepositInvEmailedDtTm = GetDate(), DepositInvEmailedUser = '{1}' Where JobRno = {0}", JobRno, g.User);
                db.Exec(Sql);
            }
        }
		catch (Exception Ex)
		{
			Err Err = new Err(Ex, Sql);
			Response.Write(Err.Html());
		}
	}

    protected void SaveCreditCardPayment()
    {
        string Sql = string.Empty;

        try
        {
            string InvoiceNum = Request.Params["UMinvoice"];
            string[] Parts = InvoiceNum.Split(new char[] { '-' });
            Int32 JobRno = Str.Num(Parts[0]);
            string PmtNum = Parts[1];
            string Status = Request.Params["UMstatus"];
            string AuthCode = Request.Params["UMauthCode"];
            string RefNum = Request.Params["UMrefNum"];
            string Error = Request.Params["UMerror"];
            string ErrorCode = Request.Params["UMerrorcode"];

            DateTime Tm = DateTime.Now;

            Sql =
                "Update mcJobs Set " +
                "PmtRef"    + PmtNum + " = "    + DB.PutStr(RefNum) + ", " +
                "CCStatus"  + PmtNum + " = "    + DB.PutStr(Status) + ", " +
                "CCResult"  + PmtNum + " = "    + DB.PutStr(Error + " - " + ErrorCode) + ", " +
                "CCAuth"    + PmtNum + " = "    + DB.PutStr(AuthCode) + ", " +
                "UpdatedDtTm = "                + DB.PutDtTm(Tm) + ", " +
                "UpdatedUser = "                + DB.PutStr(g.User) + " " +
                "Where JobRno = "               + JobRno;
            db.Exec(Sql);
        }
        catch (Exception Ex)
        {
            Err Err = new Err(Ex, Sql);
            Response.Write(Err.Html());
        }    
    }
}